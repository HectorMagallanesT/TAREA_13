﻿namespace CapaPresentacion
{
    partial class FrmEnvioADMIN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvLogistica = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLogistica)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvLogistica
            // 
            this.dgvLogistica.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvLogistica.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLogistica.Location = new System.Drawing.Point(102, 191);
            this.dgvLogistica.Margin = new System.Windows.Forms.Padding(4);
            this.dgvLogistica.Name = "dgvLogistica";
            this.dgvLogistica.RowHeadersWidth = 51;
            this.dgvLogistica.Size = new System.Drawing.Size(837, 274);
            this.dgvLogistica.TabIndex = 33;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.label1.Location = new System.Drawing.Point(354, 83);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(332, 41);
            this.label1.TabIndex = 32;
            this.label1.Text = "LOGISTICA DE ENVIO";
            // 
            // FrmEnvioADMIN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1041, 548);
            this.Controls.Add(this.dgvLogistica);
            this.Controls.Add(this.label1);
            this.Name = "FrmEnvioADMIN";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ADMIN/ENVIO";
            this.Load += new System.EventHandler(this.FrmEnvioADMIN_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.dgvLogistica)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvLogistica;
        private System.Windows.Forms.Label label1;
    }
}