﻿using CapaNegocio;
using System;
using System.Data;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class FrmEnvios : Form
    {
        private CN_Logistica cn_Logistica;

        /// <summary>
        /// Constructor de la clase FrmEnvios.
        /// </summary>
        public FrmEnvios()
        {
            InitializeComponent();
            // Inicializa la instancia de la capa de negocio relacionada con la logística
            cn_Logistica = new CN_Logistica();
        }

        /// <summary>
        /// Evento de carga del formulario FrmEnvios.
        /// </summary>
        private void FrmEnvios_Load(object sender, EventArgs e)
        {
            // Genera un número aleatorio y lo muestra en el TextBox correspondiente
            GenerarNumeros();
        }

        /// <summary>
        /// Genera un número aleatorio y lo muestra en el TextBox correspondiente.
        /// </summary>
        private void GenerarNumeros()
        {
            Random random = new Random();
            int numeroAleatorio = random.Next(100, 1000);
            txtSeguimiento.Text = numeroAleatorio.ToString();
        }

        /// <summary>
        /// Evento del botón "Enviar", realiza el proceso de envío.
        /// </summary>
        private void BtnEnviar_Click(object sender, EventArgs e)
        {
            try
            {
                // Verifica si el usuario ya tiene un envío en proceso
                if (cn_Logistica.TieneEnvioEnProceso(txtCIEnvio.Text))
                {
                    MessageBox.Show("Usted ya tiene un envío en proceso. Complete ese envío antes de realizar otro.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    LimpiarTextBox();
                    return;
                }

                // Verifica si todos los campos están llenos
                if (!CamposLlenos())
                {
                    MessageBox.Show("Complete todos los campos.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Obtiene los datos del envío desde los controles del formulario
                string seguimiento = txtSeguimiento.Text;
                string ci = txtCIEnvio.Text;
                string nombre = txtDestinatario.Text;
                string fecha = dtpFechaEnvio.Value.ToString("yyyy-MM-dd");
                string transportista = cmbTransporte.Text;
                string valor = txtValorCompra.Text;
                string descripcion = txtDescripcionCompra.Text;

                // Llama al método de la capa de negocio para insertar el envío
                cn_Logistica.InsertarEnvio(seguimiento, ci, nombre, fecha, transportista, valor, descripcion);

                MessageBox.Show("Envío realizado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Limpia los campos del formulario
                LimpiarTextBox();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al realizar el envío: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Evento que se ejecuta al cambiar el texto en el TextBox de CI de Envío.
        /// Realiza la búsqueda en la capa de negocio y actualiza los campos en el formulario.
        /// </summary>
        private void txtCIEnvio_TextChanged(object sender, EventArgs e)
        {
            // Realiza la búsqueda en la capa de negocio
            DataTable result = cn_Logistica.BuscarPagoPorCI(txtCIEnvio.Text);

            // Actualiza los campos en el formulario
            if (result.Rows.Count > 0)
            {
                txtDestinatario.Text = result.Rows[0]["NombreYApellido"].ToString();
                txtValorCompra.Text = result.Rows[0]["Total"].ToString();
            }
            else
            {
                // Limpia los campos si no se encuentra un registro
                txtDestinatario.Text = "";
                txtValorCompra.Text = "";
            }
        }

        /// <summary>
        /// Verifica si todos los campos están llenos.
        /// </summary>
        /// <returns>True si todos los campos están llenos, de lo contrario, false.</returns>
        private bool CamposLlenos()
        {
            return !string.IsNullOrWhiteSpace(txtSeguimiento.Text) &&
                   !string.IsNullOrWhiteSpace(txtCIEnvio.Text) &&
                   !string.IsNullOrWhiteSpace(txtDestinatario.Text) &&
                   !string.IsNullOrWhiteSpace(cmbTransporte.Text) &&
                   !string.IsNullOrWhiteSpace(txtValorCompra.Text) &&
                   !string.IsNullOrWhiteSpace(txtDescripcionCompra.Text);
        }

        /// <summary>
        /// Limpia los TextBox del formulario.
        /// </summary>
        private void LimpiarTextBox()
        {
            txtSeguimiento.Text = "";
            txtCIEnvio.Text = "";
            txtDestinatario.Text = "";
            dtpFechaEnvio.Value = DateTime.Now;
            cmbTransporte.SelectedIndex = -1;
            txtValorCompra.Text = "";
            txtDescripcionCompra.Text = "";
        }
    }
}
