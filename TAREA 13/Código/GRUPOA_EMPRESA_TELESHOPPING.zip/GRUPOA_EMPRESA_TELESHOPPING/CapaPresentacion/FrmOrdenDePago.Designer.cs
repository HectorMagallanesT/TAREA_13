﻿namespace CapaPresentacion
{
    partial class FrmOrdenDePago
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEliminar = new System.Windows.Forms.Button();
            this.btnActualizar = new System.Windows.Forms.Button();
            this.txtCI = new System.Windows.Forms.TextBox();
            this.lblDireccion = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblNombreYApellido = new System.Windows.Forms.Label();
            this.lblCI = new System.Windows.Forms.Label();
            this.lblTelf = new System.Windows.Forms.Label();
            this.lblPago = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblFechaHora = new System.Windows.Forms.Label();
            this.txtNombreYApellido = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtDireccion = new System.Windows.Forms.TextBox();
            this.txtFechaHora = new System.Windows.Forms.TextBox();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.txtTelf = new System.Windows.Forms.TextBox();
            this.txtPago = new System.Windows.Forms.TextBox();
            this.lblOrdenDeCompra = new System.Windows.Forms.Label();
            this.labelNombre = new System.Windows.Forms.Label();
            this.dgvOrdenGenerada = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrdenGenerada)).BeginInit();
            this.SuspendLayout();
            // 
            // btnEliminar
            // 
            this.btnEliminar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminar.Location = new System.Drawing.Point(308, 380);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(107, 39);
            this.btnEliminar.TabIndex = 38;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // btnActualizar
            // 
            this.btnActualizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnActualizar.Location = new System.Drawing.Point(173, 380);
            this.btnActualizar.Name = "btnActualizar";
            this.btnActualizar.Size = new System.Drawing.Size(106, 38);
            this.btnActualizar.TabIndex = 37;
            this.btnActualizar.Text = "Actualizar";
            this.btnActualizar.UseVisualStyleBackColor = true;
            this.btnActualizar.Click += new System.EventHandler(this.btnActualizar_Click);
            // 
            // txtCI
            // 
            this.txtCI.Enabled = false;
            this.txtCI.Location = new System.Drawing.Point(267, 72);
            this.txtCI.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtCI.Name = "txtCI";
            this.txtCI.Size = new System.Drawing.Size(240, 22);
            this.txtCI.TabIndex = 30;
            // 
            // lblDireccion
            // 
            this.lblDireccion.AutoSize = true;
            this.lblDireccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDireccion.Location = new System.Drawing.Point(67, 183);
            this.lblDireccion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDireccion.Name = "lblDireccion";
            this.lblDireccion.Size = new System.Drawing.Size(85, 18);
            this.lblDireccion.TabIndex = 29;
            this.lblDireccion.Text = "Dirección:";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Location = new System.Drawing.Point(67, 149);
            this.lblEmail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(55, 18);
            this.lblEmail.TabIndex = 28;
            this.lblEmail.Text = "Email:";
            // 
            // lblNombreYApellido
            // 
            this.lblNombreYApellido.AutoSize = true;
            this.lblNombreYApellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombreYApellido.Location = new System.Drawing.Point(67, 110);
            this.lblNombreYApellido.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNombreYApellido.Name = "lblNombreYApellido";
            this.lblNombreYApellido.Size = new System.Drawing.Size(150, 18);
            this.lblNombreYApellido.TabIndex = 27;
            this.lblNombreYApellido.Text = "Nombre y Apellido:";
            // 
            // lblCI
            // 
            this.lblCI.AutoSize = true;
            this.lblCI.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCI.Location = new System.Drawing.Point(67, 72);
            this.lblCI.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCI.Name = "lblCI";
            this.lblCI.Size = new System.Drawing.Size(29, 18);
            this.lblCI.TabIndex = 26;
            this.lblCI.Text = "CI:";
            // 
            // lblTelf
            // 
            this.lblTelf.AutoSize = true;
            this.lblTelf.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTelf.Location = new System.Drawing.Point(67, 220);
            this.lblTelf.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTelf.Name = "lblTelf";
            this.lblTelf.Size = new System.Drawing.Size(41, 18);
            this.lblTelf.TabIndex = 40;
            this.lblTelf.Text = "Telf:";
            // 
            // lblPago
            // 
            this.lblPago.AutoSize = true;
            this.lblPago.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPago.Location = new System.Drawing.Point(67, 258);
            this.lblPago.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPago.Name = "lblPago";
            this.lblPago.Size = new System.Drawing.Size(52, 18);
            this.lblPago.TabIndex = 41;
            this.lblPago.Text = "Pago:";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(70, 330);
            this.lblTotal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(51, 18);
            this.lblTotal.TabIndex = 42;
            this.lblTotal.Text = "Total:";
            // 
            // lblFechaHora
            // 
            this.lblFechaHora.AutoSize = true;
            this.lblFechaHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaHora.Location = new System.Drawing.Point(70, 296);
            this.lblFechaHora.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFechaHora.Name = "lblFechaHora";
            this.lblFechaHora.Size = new System.Drawing.Size(101, 18);
            this.lblFechaHora.TabIndex = 43;
            this.lblFechaHora.Text = "Fecha/Hora:";
            // 
            // txtNombreYApellido
            // 
            this.txtNombreYApellido.Enabled = false;
            this.txtNombreYApellido.Location = new System.Drawing.Point(267, 110);
            this.txtNombreYApellido.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtNombreYApellido.Name = "txtNombreYApellido";
            this.txtNombreYApellido.Size = new System.Drawing.Size(240, 22);
            this.txtNombreYApellido.TabIndex = 44;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(267, 149);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(240, 22);
            this.txtEmail.TabIndex = 45;
            // 
            // txtDireccion
            // 
            this.txtDireccion.Location = new System.Drawing.Point(267, 183);
            this.txtDireccion.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtDireccion.Name = "txtDireccion";
            this.txtDireccion.Size = new System.Drawing.Size(240, 22);
            this.txtDireccion.TabIndex = 46;
            // 
            // txtFechaHora
            // 
            this.txtFechaHora.Enabled = false;
            this.txtFechaHora.Location = new System.Drawing.Point(267, 292);
            this.txtFechaHora.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtFechaHora.Name = "txtFechaHora";
            this.txtFechaHora.Size = new System.Drawing.Size(240, 22);
            this.txtFechaHora.TabIndex = 47;
            // 
            // txtTotal
            // 
            this.txtTotal.Enabled = false;
            this.txtTotal.Location = new System.Drawing.Point(267, 329);
            this.txtTotal.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(240, 22);
            this.txtTotal.TabIndex = 48;
            // 
            // txtTelf
            // 
            this.txtTelf.Location = new System.Drawing.Point(267, 219);
            this.txtTelf.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtTelf.Name = "txtTelf";
            this.txtTelf.Size = new System.Drawing.Size(240, 22);
            this.txtTelf.TabIndex = 49;
            // 
            // txtPago
            // 
            this.txtPago.Enabled = false;
            this.txtPago.Location = new System.Drawing.Point(267, 257);
            this.txtPago.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtPago.Name = "txtPago";
            this.txtPago.Size = new System.Drawing.Size(240, 22);
            this.txtPago.TabIndex = 50;
            // 
            // lblOrdenDeCompra
            // 
            this.lblOrdenDeCompra.AutoSize = true;
            this.lblOrdenDeCompra.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrdenDeCompra.Location = new System.Drawing.Point(460, 22);
            this.lblOrdenDeCompra.Name = "lblOrdenDeCompra";
            this.lblOrdenDeCompra.Size = new System.Drawing.Size(405, 25);
            this.lblOrdenDeCompra.TabIndex = 51;
            this.lblOrdenDeCompra.Text = "ORDENES DE COMPRAS GENERADAS";
            // 
            // labelNombre
            // 
            this.labelNombre.AutoSize = true;
            this.labelNombre.Location = new System.Drawing.Point(12, 9);
            this.labelNombre.Name = "labelNombre";
            this.labelNombre.Size = new System.Drawing.Size(44, 16);
            this.labelNombre.TabIndex = 52;
            this.labelNombre.Text = "label1";
            this.labelNombre.Visible = false;
            // 
            // dgvOrdenGenerada
            // 
            this.dgvOrdenGenerada.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOrdenGenerada.Location = new System.Drawing.Point(602, 72);
            this.dgvOrdenGenerada.Name = "dgvOrdenGenerada";
            this.dgvOrdenGenerada.RowHeadersWidth = 51;
            this.dgvOrdenGenerada.RowTemplate.Height = 24;
            this.dgvOrdenGenerada.Size = new System.Drawing.Size(627, 323);
            this.dgvOrdenGenerada.TabIndex = 53;
            this.dgvOrdenGenerada.SelectionChanged += new System.EventHandler(this.dgvOrdenGenerada_SelectionChanged);

            // 
            // FrmOrdenDePago
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1284, 449);
            this.Controls.Add(this.dgvOrdenGenerada);
            this.Controls.Add(this.labelNombre);
            this.Controls.Add(this.lblOrdenDeCompra);
            this.Controls.Add(this.txtPago);
            this.Controls.Add(this.txtTelf);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.txtFechaHora);
            this.Controls.Add(this.txtDireccion);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.txtNombreYApellido);
            this.Controls.Add(this.lblFechaHora);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.lblPago);
            this.Controls.Add(this.lblTelf);
            this.Controls.Add(this.btnEliminar);
            this.Controls.Add(this.btnActualizar);
            this.Controls.Add(this.txtCI);
            this.Controls.Add(this.lblDireccion);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.lblNombreYApellido);
            this.Controls.Add(this.lblCI);
            this.Name = "FrmOrdenDePago";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Orden de pago generada";
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrdenGenerada)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnActualizar;
        private System.Windows.Forms.TextBox txtCI;
        private System.Windows.Forms.Label lblDireccion;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblNombreYApellido;
        private System.Windows.Forms.Label lblCI;
        private System.Windows.Forms.Label lblTelf;
        private System.Windows.Forms.Label lblPago;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblFechaHora;
        private System.Windows.Forms.TextBox txtNombreYApellido;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtDireccion;
        private System.Windows.Forms.TextBox txtFechaHora;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.TextBox txtTelf;
        private System.Windows.Forms.TextBox txtPago;
        private System.Windows.Forms.Label lblOrdenDeCompra;
        private System.Windows.Forms.Label labelNombre;
        private System.Windows.Forms.DataGridView dgvOrdenGenerada;
    }
}