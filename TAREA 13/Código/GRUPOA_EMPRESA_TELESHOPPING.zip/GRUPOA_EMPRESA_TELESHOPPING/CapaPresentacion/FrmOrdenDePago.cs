﻿
using System;
using System.Data;
using System.Globalization;
using System.Windows.Forms;
using CapaNegocio;

namespace CapaPresentacion
{
    public partial class FrmOrdenDePago : Form
    {
        private OrdenDePagoN ordenDePagoN = new OrdenDePagoN();

        /// <summary>
        /// Constructor del formulario que recibe el nombre y apellido del usuario.
        /// Inicializa el formulario y carga los datos de pago relacionados con el usuario.
        /// </summary>
        /// <param name="nombreYApellido">Nombre y apellido del usuario.</param>
        public FrmOrdenDePago(string nombreYApellido)
        {
            InitializeComponent();
            labelNombre.Text = nombreYApellido;
            CargarDatosPagoEnDataGridView(nombreYApellido);
        }


        /// <summary>
        /// Carga los datos de pago en el DataGridView para un usuario específico.
        /// Ajusta el formato de visualización de la columna FechaHora y configura el DataGridView.
        /// </summary>
        /// <param name="nombreYApellido">Nombre y apellido del usuario.</param>
        private void CargarDatosPagoEnDataGridView(string nombreYApellido)
        {
            dgvOrdenGenerada.DataSource = ordenDePagoN.CargarDatosPago(nombreYApellido);

            // Ajustar el formato de visualización de la columna FechaHora para mostrar milisegundos
            dgvOrdenGenerada.Columns["FechaHora"].DefaultCellStyle.Format = "yyyy-MM-dd HH:mm:ss.fff";

            // Configurar el DataGridView para ajustar automáticamente el ancho de la columna FechaHora
            dgvOrdenGenerada.Columns["FechaHora"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;


        }

        /// <summary>
        /// Manejador del evento que se activa al hacer clic en el botón "Actualizar".
        /// Obtiene los datos de los TextBox, realiza la actualización y actualiza la interfaz.
        /// </summary>
        private void btnActualizar_Click(object sender, EventArgs e)
        {
            // Obtén los datos de los TextBox
            string ci = txtCI.Text;
            string nombreYApellido = txtNombreYApellido.Text;
            string email = txtEmail.Text;
            string direccion = txtDireccion.Text;
            string telf = txtTelf.Text;
            string pago = txtPago.Text;
            DateTime fechaHora = DateTime.ParseExact(txtFechaHora.Text, "yyyy-MM-dd HH:mm:ss.fff", System.Globalization.CultureInfo.InvariantCulture);
            decimal total = decimal.Parse(txtTotal.Text);

            // Realiza la actualización llamando al método en la capa de negocio
            bool actualizado = ordenDePagoN.ActualizarRegistro(ci, nombreYApellido, email, direccion, telf, pago, fechaHora, total);

            if (actualizado)
            {
                // Actualización exitosa
                MessageBox.Show("Registro actualizado con éxito.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Actualiza el DataGridView
                CargarDatosPagoEnDataGridView(labelNombre.Text);
                LimpiarTextBox();
            }
            else
            {
                MessageBox.Show("No se pudo actualizar el registro.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Manejador del evento que se activa al hacer clic en el botón "Eliminar".
        /// Obtiene la fecha y hora del TextBox, realiza la eliminación y actualiza la interfaz.
        /// </summary>
        private void btnEliminar_Click(object sender, EventArgs e)
        {
            // Obtén la fecha y hora de txtFechaHora para eliminar el registro
            DateTime fechaHora = DateTime.ParseExact(txtFechaHora.Text, "yyyy-MM-dd HH:mm:ss.fff", System.Globalization.CultureInfo.InvariantCulture);

            // Realiza la eliminación llamando al método en la capa de negocio
            bool eliminado = ordenDePagoN.EliminarRegistro(fechaHora);

            if (eliminado)
            {
                // Eliminación exitosa
                MessageBox.Show("Registro eliminado con éxito.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Actualiza el DataGridView
                CargarDatosPagoEnDataGridView(labelNombre.Text);
                LimpiarTextBox();
            }
            else
            {
                MessageBox.Show("No se pudo eliminar el registro.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Manejador del evento que se activa cuando cambia la selección en el DataGridView.
        /// Muestra los valores seleccionados en los TextBox correspondientes para su edición.
        /// </summary>
        private void dgvOrdenGenerada_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvOrdenGenerada.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dgvOrdenGenerada.SelectedRows[0];

                string ci = selectedRow.Cells["CI"].Value.ToString();
                string nombreYApellido = selectedRow.Cells["NombreYApellido"].Value.ToString();
                string email = selectedRow.Cells["Email"].Value.ToString();
                string direccion = selectedRow.Cells["Direccion"].Value.ToString();
                string telf = selectedRow.Cells["Telf"].Value.ToString();
                string pago = selectedRow.Cells["Pago"].Value.ToString();
                DateTime fechaHora = Convert.ToDateTime(selectedRow.Cells["FechaHora"].Value); // Convertir a DateTime
                string total = selectedRow.Cells["Total"].Value.ToString();

                // Mostrar los valores en los TextBox correspondientes
                txtCI.Text = ci;
                txtNombreYApellido.Text = nombreYApellido;
                txtEmail.Text = email;
                txtDireccion.Text = direccion;
                txtTelf.Text = telf;
                txtPago.Text = pago;

                // Formatea la fecha como deseas antes de asignarla al campo txtFechaHora
                txtFechaHora.Text = fechaHora.ToString("yyyy-MM-dd HH:mm:ss.fff");

                txtTotal.Text = total;
            }
        }

        /// <summary>
        /// Limpia los valores en los TextBox.
        /// </summary>
        private void LimpiarTextBox()
        {
            txtCI.Text = "";
            txtNombreYApellido.Text = "";
            txtEmail.Text = "";
            txtDireccion.Text = "";
            txtTelf.Text = "";
            txtPago.Text = "";
            txtFechaHora.Text = "";
            txtTotal.Text = "";
        }

    }
}
