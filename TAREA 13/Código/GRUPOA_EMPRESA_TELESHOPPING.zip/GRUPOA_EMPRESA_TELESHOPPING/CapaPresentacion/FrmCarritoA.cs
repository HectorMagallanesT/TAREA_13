﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaDatos;
using CapaNegocio;

namespace CapaPresentacion
{
    public partial class FrmCarritoA : Form
    {
        CN_Productos carritoComprasNegocio = new CN_Productos();
        private string nombreYApellido;

        // Variable para acceder a la capa de datos usuarioD
        private ModulosD ModulosD;

        // Cadena de conexión a la base de datos
        private string connectionString = "Data Source=HECTOR;Initial Catalog=GrupoATeleshopping;Integrated Security=True";

        /// <summary>
        /// Constructor de la clase FrmCarritoA sin argumentos.
        /// </summary>
        public FrmCarritoA()
        {
            InitializeComponent();
            dgvProductosC.DataSource = carritoComprasNegocio.ObtenerCarritoComprasAgrupado(nombreYApellido);
        }

        /// <summary>
        /// Constructor de la clase FrmCarritoA con nombre y apellido como argumento.
        /// </summary>
        /// <param name="nombreYApellido">Nombre y apellido del usuario.</param>
        public FrmCarritoA(string nombreYApellido)
        {
            InitializeComponent();
            this.nombreYApellido = nombreYApellido;
            Actualizar();
        }

        /// <summary>
        /// Maneja el evento Load del formulario.
        /// </summary>
        private void FrmCarritosA_Load(object sender, EventArgs e)
        {
            dgvProductosC.DataSource = carritoComprasNegocio.ObtenerCarritoComprasAgrupado(nombreYApellido);
        }

        /// <summary>
        /// Actualiza los datos del carrito de compras.
        /// </summary>
        public void Actualizar()
        {
            dgvProductosC.DataSource = carritoComprasNegocio.ObtenerCarritoComprasAgrupado(nombreYApellido);
        }

        /// <summary>
        /// Hace visibles los botones relacionados con el pago.
        /// </summary>
        public void HacerBotonesVisibles()
        {
            btnPago.Visible = true;
        }

        /// <summary>
        /// Maneja el evento Click del botón de pago.
        /// Abre el formulario de pagos.
        /// </summary>
        private void btnPago_Click(object sender, EventArgs e)
        {
            // Crear una instancia del formulario FrmPagos
            FrmPagos frmPagos = new FrmPagos();

            // Mostrar el formulario
            frmPagos.Show();
        }
    }
}
