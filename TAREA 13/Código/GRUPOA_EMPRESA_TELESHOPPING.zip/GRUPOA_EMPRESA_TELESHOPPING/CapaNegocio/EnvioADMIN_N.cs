﻿using CapaDatos;
using System;
using System.Data;

namespace CapaNegocio
{
    /// <summary>
    /// Clase de la capa de negocio que actúa como intermediario entre la capa de presentación y la capa de datos para la entidad "Envio" en el contexto de administradores.
    /// </summary>
    public class EnvioADMIN_N
    {
        private EnvioADMIN_D envioADMIN_D;

        /// <summary>
        /// Constructor de la clase EnvioADMIN_N.
        /// </summary>
        public EnvioADMIN_N()
        {
            // Inicializa la instancia de la capa de datos relacionada con Envio para administradores
            envioADMIN_D = new EnvioADMIN_D();
        }

        /// <summary>
        /// Obtiene los datos de todos los envíos.
        /// </summary>
        /// <returns>DataTable con los datos de los envíos.</returns>
        public DataTable ObtenerDatosEnvio()
        {
            // Delega la llamada al método correspondiente en la capa de datos
            return envioADMIN_D.ObtenerDatosEnvio();
        }
    }
}
