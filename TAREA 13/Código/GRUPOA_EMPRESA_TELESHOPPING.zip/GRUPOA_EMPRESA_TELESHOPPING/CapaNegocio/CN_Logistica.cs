﻿using CapaDatos;
using System;
using System.Data;

namespace CapaNegocio
{
    public class CN_Logistica
    {
        private CD_Logistica cd_Logistica;

        public CN_Logistica()
        {
            cd_Logistica = new CD_Logistica();
        }

        /// <summary>
        /// Obtiene todos los registros de envíos desde la capa de datos.
        /// </summary>
        /// <returns>DataTable con los registros de envíos.</returns>
        public DataTable ObtenerEnvios()
        {
            return cd_Logistica.ObtenerEnvios();
        }

        /// <summary>
        /// Inserta un nuevo registro de envío utilizando la capa de datos.
        /// </summary>
        public void InsertarEnvio(string seguimiento, string ci, string nombre, string fecha, string transportista, string valor, string descripcion)
        {
            cd_Logistica.InsertarEnvio(seguimiento, ci, nombre, fecha, transportista, valor, descripcion);
        }

        /// <summary>
        /// Verifica si un usuario tiene envíos en proceso.
        /// </summary>
        /// <param name="ci">Cédula de identidad del usuario.</param>
        /// <returns>True si tiene envíos en proceso, false de lo contrario.</returns>
        public bool TieneEnvioEnProceso(string ci)
        {
            int cantidadEnvios = cd_Logistica.ObtenerCantidadEnviosEnProceso(ci);
            return cantidadEnvios > 0;
        }

        /// <summary>
        /// Busca un pago por CI y devuelve el nombre y el total utilizando la capa de datos.
        /// </summary>
        public DataTable BuscarPagoPorCI(string ci)
        {
            return cd_Logistica.BuscarPagoPorCI(ci);
        }
    }
}
