using CapaPresentacion;
using CapaDatos;
using CapaNegocio;
using NUnit.Framework;
using System.Data.SqlClient;


namespace Pruebas{

    [TestFixture]
public class RegistroDeUsuarioTests
{
    private LoginUsuarioN loginUsuarioN;

    [OneTimeSetUp]
    public void OneTimeSetup()
    {
        // Configura la conexi�n a la base de datos si es necesario para tus pruebas
        string connectionString = "Data Source=HECTOR;Initial Catalog=GrupoATeleshopping;Integrated Security=True";
        loginUsuarioN = new LoginUsuarioN(connectionString);
    }

        [Test]
        public void RegistroDeUsuarioExitoso()
        {
            // Arrange: Preparaci�n de datos para la prueba
            string nombreYApellido = "Mar�o Basurto";
            string ci = "0950722823";
            string email = "marioB08@gmail.com";
            string contrasena = "Mario08B";
            string confirmarContrasena = "Mario08B";

            // Act: Acci�n que se est� probando
            bool registroExitoso = loginUsuarioN.CrearUsuario(nombreYApellido, ci, email, contrasena, confirmarContrasena);

            // Assert: Verificar el resultado esperado
            Assert.True(registroExitoso, "El registro de usuario es exitoso.");
        }

 
        [Test]
    public void RegistroDeUsuarioFallido()
    {
        // Arrange: Preparaci�n de datos para la prueba
        string nombreYApellido = "Juan P�rez";
        string ci = "1234567890"; // CI incorrecto
        string email = "juan@hotmail.com";
        string contrasena = "juan123";
        string confirmarContrasena = "juan12345";

            // Act: Acci�n que se est� probando
            bool registroExitoso = loginUsuarioN.CrearUsuario(nombreYApellido, ci, email, contrasena, confirmarContrasena);

            // Assert: Verificar el resultado esperado
            Assert.IsFalse(registroExitoso, "El registro de usuario ha fallado.");
       
    }
 
    }
}
