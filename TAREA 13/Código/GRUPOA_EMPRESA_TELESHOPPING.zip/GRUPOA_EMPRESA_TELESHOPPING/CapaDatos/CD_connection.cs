﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace CapaDatos
{
    public class CD_Connection
    {
        // Declaración de una instancia de SqlConnection para manejar la conexión a la base de datos.
        private SqlConnection conexion = new SqlConnection("Data Source=HECTOR;Initial Catalog=GrupoATeleshopping;Integrated Security=True");

        // Método para abrir la conexión a la base de datos.
        public SqlConnection AbrirConexion()
        {
            try
            {
                // Verifica si la conexión está cerrada y la abre si es necesario.
                if (conexion.State == ConnectionState.Closed)
                    conexion.Open();
                return conexion; // Devuelve la conexión abierta.
            }
            catch (Exception ex)
            {
                // Manejo de excepciones en caso de error al abrir la conexión.
                throw ex; // Relanza la excepción para que sea manejada en un nivel superior.
            }
        }

        // Método para cerrar la conexión a la base de datos.
        public SqlConnection CerrarConexion()
        {
            try
            {
                // Verifica si la conexión está abierta y la cierra si es necesario.
                if (conexion.State == ConnectionState.Open)
                    conexion.Close();
                return conexion; // Devuelve la conexión cerrada.
            }
            catch (Exception ex)
            {
                // Manejo de excepciones en caso de error al cerrar la conexión.
                throw ex; // Relanza la excepción para que sea manejada en un nivel superior.
            }
        }
    }
}
