﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class CD_Productos
    {
        private CD_Connection conn = new CD_Connection();


        /// <summary>
        /// Obtiene un DataTable con todos los productos.
        /// </summary>
        /// <returns>DataTable con los productos.</returns>
        public DataTable getProductos()
        {
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter adapter;

            // Abre la conexión 
            cmd.Connection = conn.AbrirConexion();

            // Establece el comando como un procedimiento almacenado
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "sp_GetProductos"; // Nombre del procedimiento almacenado

            // Ejecuta y asigna al adaptador
            adapter = new SqlDataAdapter(cmd);

            // Asigna los resultados al DataTable
            adapter.Fill(dt);

            return dt;
        }


        /// <summary>
        /// Inserta un nuevo producto en la base de datos.
        /// </summary>
        /// <param name="foto">Imagen del producto.</param>
        /// <param name="nombre">Nombre del producto.</param>
        /// <param name="descripcion">Descripción del producto.</param>
        /// <param name="precio">Precio del producto.</param>
        /// <returns>True si la inserción fue exitosa, de lo contrario, false.</returns>

        public bool InsertarProducto(byte[] foto, string nombre, string descripcion, decimal precio)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn.AbrirConexion();

            // Establece el comando como un procedimiento almacenado
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "sp_InsertarProducto"; // Nombre del procedimiento almacenado

            // Agrega parámetros al comando
            cmd.Parameters.AddWithValue("@Foto", foto);
            cmd.Parameters.AddWithValue("@Nombre", nombre);
            cmd.Parameters.AddWithValue("@Descripcion", descripcion);
            cmd.Parameters.AddWithValue("@Precio", precio);

            cmd.ExecuteNonQuery();
            conn.CerrarConexion();

            return true;
        }


        /// <summary>
        /// Busca productos por nombre y obtiene un DataTable con los resultados.
        /// </summary>
        /// <param name="nombreProducto">Nombre del producto a buscar.</param>
        /// <returns>DataTable con los productos que coinciden con el nombre.</returns>
        public DataTable BuscarProductosPorNombre(string nombreProducto)
        {
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter adapter;

            // Abre la conexión a la base de datos
            cmd.Connection = conn.AbrirConexion();

            // Establece el comando como un procedimiento almacenado
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "sp_BuscarProductosPorNombre"; // Nombre del procedimiento almacenado

            // Agrega el parámetro al comando
            cmd.Parameters.AddWithValue("@Nombre", nombreProducto);

            // Ejecuta la consulta y asigna los resultados al adaptador
            adapter = new SqlDataAdapter(cmd);

            // Rellena el DataTable con los resultados
            adapter.Fill(dt);

            return dt;
        }


        /// <summary>
        /// Elimina un producto de la base de datos.
        /// </summary>
        /// <param name="productoID">ID del producto a eliminar.</param>
        /// <returns>True si la eliminación fue exitosa, de lo contrario, false.</returns>
        public bool EliminarProducto(int productoID)
        {

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn.AbrirConexion();

            // Establece el comando como un procedimiento almacenado
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "sp_EliminarProducto"; // Nombre del procedimiento almacenado

            // Agrega parámetros al comando
            cmd.Parameters.AddWithValue("@ProductoID", productoID);


            cmd.ExecuteNonQuery();
            conn.CerrarConexion();

            return true;
        }


        /// <summary>
        /// Modifica un producto en la base de datos.
        /// </summary>
        /// <param name="productoID">ID del producto a modificar.</param>
        /// <param name="foto">Nueva imagen del producto.</param>
        /// <param name="nombre">Nuevo nombre del producto.</param>
        /// <param name="descripcion">Nueva descripción del producto.</param>
        /// <param name="precio">Nuevo precio del producto.</param>
        /// <returns>True si la modificación fue exitosa, de lo contrario, false.</returns>
        public bool ModificarProducto(int productoID, byte[] foto, string nombre, string descripcion, decimal precio)
        {
            SqlConnection sqlConnection = null;

            try
            {
                CD_Connection conn = new CD_Connection();
                sqlConnection = conn.AbrirConexion();

                SqlCommand sqlCommand = new SqlCommand("sp_ModificarProducto", sqlConnection);
                sqlCommand.CommandType = CommandType.StoredProcedure;

                sqlCommand.Parameters.AddWithValue("@ID", productoID);

                // Verificar si se proporciona una nueva imagen
                if (foto != null)
                {
                    sqlCommand.Parameters.AddWithValue("@Foto", foto);
                }
                else
                {
                    // Si no se proporciona una nueva imagen, establecer el parámetro como nulo
                    sqlCommand.Parameters.Add(new SqlParameter("@Foto", SqlDbType.VarBinary, -1));
                    sqlCommand.Parameters["@Foto"].Value = DBNull.Value;
                }

                sqlCommand.Parameters.AddWithValue("@Nombre", nombre);
                sqlCommand.Parameters.AddWithValue("@Descripcion", descripcion);
                sqlCommand.Parameters.AddWithValue("@Precio", precio);

                sqlCommand.ExecuteNonQuery();

                return true; // La operación se realizó con éxito
            }
            catch (Exception ex)
            {
                // Manejo de excepciones en caso de error
                // Puedes registrar el error o lanzar una excepción personalizada si lo deseas
                return false; // La operación no se pudo completar
            }
            finally
            {
                if (sqlConnection != null)
                {
                    sqlConnection.Close();
                }
            }
        }


        /// <summary>
        /// Inserta un producto en el carrito de compras de un usuario.
        /// </summary>
        /// <param name="nombreUsuario">Nombre de usuario al que se le agregará el producto al carrito.</param>
        /// <param name="productoID">ID del producto que se va a agregar al carrito.</param>
        /// <param name="cantidad">Cantidad del producto a agregar.</param>
        /// <param name="descripcion">Descripción del producto a agregar.</param>
        /// <param name="precio">Precio del producto a agregar.</param>
        public void InsertarProductoEnCarrito(string nombreUsuario, int productoID, int cantidad, string descripcion, decimal precio)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn.AbrirConexion();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "sp_InsertarProductoEnCarrito"; // Nombre del procedimiento almacenado

            cmd.Parameters.AddWithValue("@NombreUsuario", nombreUsuario);
            cmd.Parameters.AddWithValue("@ProductoID", productoID);
            cmd.Parameters.AddWithValue("@Cantidad", cantidad);
            cmd.Parameters.AddWithValue("@Descripcion", descripcion);
            cmd.Parameters.AddWithValue("@Precio", precio);

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                // Manejo de excepciones en caso de error
                // Puedes registrar el error o lanzar una excepción personalizada si lo deseas
            }
            finally
            {
                conn.CerrarConexion();
            }
        }


        /// <summary>
        /// Obtiene un DataTable con los productos en el carrito de compras agrupados por usuario.
        /// </summary>
        /// <param name="nombreUsuario">Nombre de usuario para el que se agruparán los productos en el carrito.</param>
        /// <returns>DataTable con los productos en el carrito de compras agrupados por usuario.</returns>
        public DataTable ObtenerCarritoComprasAgrupado(string nombreUsuario)
        {
            using (SqlConnection connection = conn.AbrirConexion())
            {
                using (SqlCommand command = new SqlCommand("sp_CalcularCantidadAgrupada", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    // Agregar el parámetro para el nombre de usuario
                    command.Parameters.AddWithValue("@NombreUsuario", nombreUsuario);

                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        return dataTable;
                    }
                }
            }
        }



        /// <summary>
        /// Modifica un producto en la base de datos.
        /// </summary>
        /// <param name="productoID">ID del producto a modificar.</param>
        /// <param name="foto">Nueva imagen del producto.</param>
        /// <param name="nombre">Nuevo nombre del producto.</param>
        /// <param name="descripcion">Nueva descripción del producto.</param>
        /// <param name="precio">Nuevo precio del producto.</param>
        /// <returns>True si la modificación fue exitosa, de lo contrario, false.</returns>
        public bool ModificarProducto(int productoID, string nuevoNombre, string nuevaDescripcion, decimal nuevoPrecio)
        {
            throw new NotImplementedException();
        }
    }

}
